::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::
::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::
::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::
::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::

Database Name: POS-system 

Recommended PHP Version 5.6+


::::::::::::::::Admin Login Details::::::::::::::

Username: admin
Password: alphacodecamp

::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::
::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::
::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::
::::::::::::::Visit alphacodecamp.com.ng for more PHP projects:::::::::::::::::